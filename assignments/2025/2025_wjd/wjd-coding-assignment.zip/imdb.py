import numpy as np
from datasets import load_dataset,concatenate_datasets
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
import matplotlib.pyplot as plt

# 设置随机种子以确保可重复性
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# 1. 加载并分割数据
print("步骤1: 加载和分割数据...")
ds = load_dataset("imdb")

# 合并训练和测试数据以进行重新分割
combined_dataset = concatenate_datasets([ds["train"], ds["test"]])
texts = combined_dataset["text"]
labels = combined_dataset["label"]

# 70/15/15 分割
X_temp, X_test, y_temp, y_test = train_test_split(
    texts, labels, test_size=0.15, random_state=RANDOM_SEED, stratify=labels
)

X_train, X_val, y_train, y_val = train_test_split(
    X_temp, y_temp, test_size=0.1765, random_state=RANDOM_SEED, stratify=y_temp
)  # 0.1765 ≈ 0.15/(0.15+0.70)

print(f"训练集大小: {len(X_train)}")
print(f"验证集大小: {len(X_val)}")
print(f"测试集大小: {len(X_test)}")
print(f"积极评价比例 (训练集): {sum(y_train)/len(y_train):.2%}")
print()

# 2. 预处理特征 - 使用TF-IDF
print("步骤2: 特征提取 (TF-IDF)...")
# 也可以选择使用CountVectorizer()来获取词袋模型特征
vectorizer = TfidfVectorizer(max_features=10000, stop_words='english')
X_train_vec = vectorizer.fit_transform(X_train)
X_val_vec = vectorizer.transform(X_val)
X_test_vec = vectorizer.transform(X_test)

print(f"特征维度: {X_train_vec.shape[1]}")
print()

# 3. 训练朴素贝叶斯模型
print("步骤3: 训练朴素贝叶斯模型...")
nb_model = MultinomialNB(alpha=1.0)  # Laplace平滑，alpha=1.0
nb_model.fit(X_train_vec, y_train)

# 在验证集上评估
y_val_pred_nb = nb_model.predict(X_val_vec)
nb_val_accuracy = accuracy_score(y_val, y_val_pred_nb)
nb_val_f1 = f1_score(y_val, y_val_pred_nb)

print(f"朴素贝叶斯验证集准确率: {nb_val_accuracy:.4f}")
print(f"朴素贝叶斯验证集F1分数: {nb_val_f1:.4f}")
print()

# 4. 训练逻辑回归模型并调参
print("步骤4: 训练逻辑回归模型并调参...")
best_score = 0
best_C = None
best_lr_model = None

C_values = [0.1, 1, 10]

for C in C_values:
    print(f"  尝试 C={C}...")
    lr_model = LogisticRegression(
        C=C, 
        max_iter=200, 
        random_state=RANDOM_SEED,
        penalty='l2',  # ℓ2正则化
        solver='liblinear'  # 适用于二分类小数据集
    )
    lr_model.fit(X_train_vec, y_train)
    
    # 在验证集上评估
    y_val_pred_lr = lr_model.predict(X_val_vec)
    val_accuracy = accuracy_score(y_val, y_val_pred_lr)
    val_f1 = f1_score(y_val, y_val_pred_lr)
    
    if val_accuracy > best_score:
        best_score = val_accuracy
        best_C = C
        best_lr_model = lr_model
    
    print(f"    C={C}: 验证集准确率 = {val_accuracy:.4f}, 验证集f1 = {val_f1:.4f}")

print(f"最佳C值: {best_C}")
print()

# 使用最佳C在训练+验证集上重新训练
print(f"使用最佳C值({best_C})在训练+验证集上重新训练逻辑回归模型...")
X_train_val_vec = vectorizer.transform(X_train + X_val)
y_train_val = y_train + y_val

final_lr_model = LogisticRegression(
    C=best_C, 
    max_iter=200, 
    random_state=RANDOM_SEED,
    penalty='l2',
    solver='liblinear'
)
final_lr_model.fit(X_train_val_vec, y_train_val)
print()

# 5. 在测试集上评估两个模型
print("步骤5: 在测试集上评估模型...")

# 朴素贝叶斯在测试集上的表现
y_test_pred_nb = nb_model.predict(X_test_vec)
nb_test_accuracy = accuracy_score(y_test, y_test_pred_nb)
nb_test_f1 = f1_score(y_test, y_test_pred_nb)

print(f"朴素贝叶斯测试集准确率: {nb_test_accuracy:.4f}")
print(f"朴素贝叶斯测试集F1分数: {nb_test_f1:.4f}")

# 逻辑回归在测试集上的表现（使用重新训练的模型）
y_test_pred_lr = final_lr_model.predict(X_test_vec)
lr_test_accuracy = accuracy_score(y_test, y_test_pred_lr)
lr_test_f1 = f1_score(y_test, y_test_pred_lr)

print(f"逻辑回归测试集准确率: {lr_test_accuracy:.4f}")
print(f"逻辑回归测试集F1分数: {lr_test_f1:.4f}")
print()

# 6. 诊断分析
print("步骤6: 模型诊断分析...")
print()

# 获取特征名称
feature_names = vectorizer.get_feature_names_out()

# 朴素贝叶斯诊断 - 找出每个类别最具指示性的特征
print("朴素贝叶斯诊断: 每个类别最具指示性的10个特征")

# 计算对数概率比 (log P(word|pos) / P(word|neg))
log_prob_ratio = nb_model.feature_log_prob_[1] - nb_model.feature_log_prob_[0]  # pos - neg

# 获取最高和最低的对数概率比
top_pos_indices = np.argsort(log_prob_ratio)[-10:]  # 最可能出现在积极评价中的词
top_neg_indices = np.argsort(log_prob_ratio)[:10]   # 最可能出现在消极评价中的词

print("积极评价最具指示性的10个特征:")
for idx in reversed(top_pos_indices):
    word = feature_names[idx]
    ratio = log_prob_ratio[idx]
    print(f"  {word}: {ratio:.4f}")

print("\n消极评价最具指示性的10个特征:")
for idx in top_neg_indices:
    word = feature_names[idx]
    ratio = log_prob_ratio[idx]
    print(f"  {word}: {ratio:.4f}")

print()

# 逻辑回归诊断 - 查看权重绝对值最大的特征
print("逻辑回归诊断: ")

# 获取逻辑回归权重
lr_weights = final_lr_model.coef_[0]

# 获取权重绝对值最大的特征
top_pos_indices = np.argsort(lr_weights)[-10:]  # 最可能出现在积极评价中的词
top_neg_indices = np.argsort(lr_weights)[:10]

print("积极评价最具指示性的10个特征:")
for idx in reversed(top_pos_indices):
    word = feature_names[idx]
    weight = lr_weights[idx]
    print(f"  {word}: {weight:.4f}")

print("\n消极评价最具指示性的10个特征:")
for idx in top_neg_indices:
    word = feature_names[idx]
    weight = lr_weights[idx]
    print(f"  {word}: {weight:.4f}")

print()

# 额外的可视化
print("可视化: 逻辑回归权重分布")
plt.figure(figsize=(12, 5))
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 绘制逻辑回归权重分布
plt.subplot(1, 2, 1)
plt.hist(lr_weights, bins=50, edgecolor='black', alpha=0.7)
plt.title('逻辑回归权重分布')
plt.xlabel('权重值')
plt.ylabel('频率')
plt.grid(True, alpha=0.3)

# 绘制朴素贝叶斯对数概率比分布
plt.subplot(1, 2, 2)
plt.hist(log_prob_ratio, bins=50, edgecolor='black', alpha=0.7, color='green')
plt.title('朴素贝叶斯对数概率比分布')
plt.xlabel('log(P(word|pos)/P(word|neg))')
plt.ylabel('频率')
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('model_diagnostics.png', dpi=150, bbox_inches='tight')
print("诊断图表已保存为 'model_diagnostics.png'")

# 结果总结
print("\n" + "="*50)
print("结果总结:")
print("="*50)
print(f"数据集大小:")
print(f"  训练集: {len(X_train)} 条评价")
print(f"  验证集: {len(X_val)} 条评价")
print(f"  测试集: {len(X_test)} 条评价")

print(f"\n模型性能:")
print(f"  朴素贝叶斯 - 准确率: {nb_test_accuracy:.4f}, F1分数: {nb_test_f1:.4f}")
print(f"  逻辑回归 (C={best_C}) - 准确率: {lr_test_accuracy:.4f}, F1分数: {lr_test_f1:.4f}")

print(f"\n特征维度: {X_train_vec.shape[1]}")